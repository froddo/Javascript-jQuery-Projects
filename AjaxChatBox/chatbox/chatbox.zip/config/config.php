<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'frodo');
define('DB_PASS', 'qwerty');
define('DB_NAME', 'chatbox');